module MyProject {
	exports javaproject;
}