package javaproject;

public class MyProject {
	
	    public static int getMax( int [] n ){
	        int max= n[0];
	 for(int i=0; i<6; i++)
	     if(n[i]>max)
	         max= n[i];
	        return max ;
	    }
	  
	    public static void main(String[] args) {
	 // TODO code application logic here
	 int [] num = {3, 5, 8, 220, 4, 9,};
	 
	   int max = getMax (num);
	 
	    System.out.println("max= "+max);
	 
	    }
	    
	}

